#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
//#include <unistd.h>
#include <string.h>
#include <string.h>

// #define PAMAX 250

// for fexist
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>

#include <unistd.h>  //define getcwd

#include <ncurses.h>

/// C based libraries (no ncurses)
#include "../libc/libc-bin.c"
#include "../libc/libc-strings.c"

/// C based libraries (with ncurses)
#include "../libnc/libnc-files.c"
#include "../libnc/libnc-extapps.c"

/// C based libraries (with ncurses) - user apps
#include "../libnc/libnc-menu-tools.c"







int main()
{	
    char line[250];
    char cmdi[250];
    char filetarget[250];
    char idata[1240][250];
    char cwd[PATH_MAX];
    char pathbefore[PATH_MAX];
    strncpy( pathbefore , getcwd( cwd, PATH_MAX ) , PATH_MAX );
    int foo ;
    char pathmem[12][PATH_MAX];
    for( foo = 0 ; foo <= 10 ; foo++)
    {
      strncpy( pathmem[foo] , getcwd( cwd, PATH_MAX ) , PATH_MAX );
    }
    int showhiddenfiles = 0;

    unsigned filemax = 0;
    unsigned n=0;
    DIR *dirp;
    struct dirent *dp;

    int selection = 0 ; 
    int selectionmax = 0 ; 
    int scrolly=0; 


   void loadlist(){
    n = 0 ; 
    filemax = 0; 
    dirp = opendir( "." );
    strncpy( idata[ n++ ] , ".." , 250 );
    while  ((dp = readdir( dirp )) != NULL  &&  
            n < sizeof idata / sizeof idata[ 0 ]) {
            if ( strcmp( dp->d_name , "." ) != 0 )
            if ( ( showhiddenfiles == 0 ) && ( dp->d_name[0] != '.' ) )
            {
              strncpy( idata[ n++ ] , dp->d_name , 250 );
            }
    }
    filemax = n-1 ; 
    closedir( dirp );

    if ( n > 1 )
      qsort( idata, n , sizeof idata[0], compare_fun );

    for( n = 0 ; n <= filemax ; n++)
    {
       //printf( "%s\n" , idata[ n ] );
    }
    selectionmax = filemax ;
    if ( selection >= selectionmax ) selection = 0;
   }


    /////////////
    loadlist();

    initscr();			/* Start curses mode 		  */
    curs_set( 0 );

    int ch ; 
    int rows, cols;  
    getmaxyx( stdscr, rows, cols);


   void checkvars(){
      if ( selection <= 0 ) selection = 0;
      if ( scrolly <= 0 ) scrolly = 0;
      if ( selection >= filemax ) selection = filemax; 
   }


   void drawit(){
    clear();
    int posy=2;
    for( n = 0 ; n <= filemax ; n++)
    {
        if ( n >= scrolly )  
        if ( posy <= rows-3 )  
        {
          if ( selection == n ) mvprintw( posy , 0, ">" );
          if ( selection == n ) attron(  A_REVERSE );
          if ( fexist( idata[ n ] ) == 2 )
            mvprintw( posy , 1, "[%s]", idata[ n ] );
          else
            mvprintw( posy , 1, "%s", idata[ n ] );
          posy++;
          attroff(  A_REVERSE );
        }
    }
   }

   void mvfulllinereverse( int posyy ){
    attron(  A_REVERSE ); 
    for( foo = 0 ; foo <= cols-1 ; foo++) mvaddch( posyy , foo , ' ');
    attroff( A_REVERSE );
   }

   void displaystatus(){
    mvfulllinereverse( 0 ); 
    attron(  A_REVERSE ); 
    mvaddch( 0 , 1,  ' ' );
    printw( "NCDIRVIEW  ");
    addch(  ACS_DARROW);
    //mvaddch( 0 , 1,  ACS_DARROW);
    printw( ":j  ");
    addch(  ACS_UARROW);
    printw( ":k  ");
    addch(  ACS_ULCORNER );
    printw( ":g  ");
    addch(  ACS_DIAMOND);
    printw( ":o  ");
    attroff( A_REVERSE );
    mvfulllinereverse( rows-2 ); 
    mvfulllinereverse( rows-1 ); 
    attron( A_REVERSE );
    mvprintw(rows-2 , 0, "PATH: %s", getcwd( cwd, PATH_MAX ) );
    mvprintw(rows-1 , 0, "User:%s, Selection #%d/%d, P:%d, PD:%s" , getenv( "USER" ) ,  selection+1, selectionmax+1, scrolly, idata[ selection ] );
    attroff( A_REVERSE );
   }

   int menu_gameover = 0;
   while ( menu_gameover == 0 ){ 
        checkvars();
        drawit();
        displaystatus();
	refresh();			/* Print it on to the real screen */
	ch = getch();			/* Wait for user input */
        switch( ch ){

               case 'q':
                  menu_gameover = 1;
                  break;

               case 'G':
                  selection = selectionmax ;
                  break;

               case 'g':
                  mvprintw(0,0,"[g]");
                  ch = getch();
                  if      ( ch == 'g' ) { selection = 0;  scrolly=0; }
                  else if ( ch == 'G' ) selection = selectionmax ;
                  break;

               case '"':
               case 'p':
                  mvprintw( 0, 0, "[STO MEM (PILE #1-9)?]" ) ;
                  refresh();
                  ch = getch();
                  foo = ch - 48 ;
                  if ( foo >= 1 )
                  if ( foo <= 9 )
                  { // chdir( pathmem[foo] );
                     mvprintw( 0, 0, "[STO MEM #%d]" , foo ) ;
                     strncpy( pathmem[foo] , getcwd( cwd, PATH_MAX ) , PATH_MAX );
                     loadlist();
                  }
                 break;

               case '1':
               case '2':
               case '3':
               case '4':
               case '5':
               case '6':
               case '7':
               case '8':
               case '9':
                  foo = ch - 48 ;
                  mvprintw( 0, 0, "[REC MEM #%d]" , foo ) ;
                  if ( foo >= 1 )
                  if ( foo <= 9 )
                  {  chdir( pathmem[foo] );
                     selection = 0;
                     loadlist();
                  }
                  break;

               case 'b':
                  mvprintw(0,0,"[b]");
                  ch = getch();
                  if      ( ch == 'g' ) {  chdir( pathbefore );
                                           loadlist();
                                        }
                  break;

               case '#':
                  loadlist();
                  break;

               case 'k':
                  selection--;
                  break;
               case 'j':
                  selection++;
                  break;

               case 'd':
                  selection+= 4;
                  scrolly+= 4;
                  break;
               case 'u':
                  selection-= 4;
                  scrolly-= 4;
                  break;

               case 'h':
                   chdir( ".." );
                   selection = 0; 
                   selection = 0;  scrolly=0; 
                   loadlist();
                   break;

               case 'l':
                  if ( fexist( idata[ selection ] ) == 2 )
                  {
                    chdir( idata[ selection ] ); 
                    selection = 0;  scrolly=0; 
                    loadlist();
                  }
                  break;


               case 'v':
                  if ( fexist( idata[ selection ] ) == 1 )
                    nrunwith(  " vim " ,  idata[ selection ] ); 
                    break;
                
               case 'M':
	        libnc_menu_tools();
                break;

               case 'm':
                  mvprintw( 0, 0,"[m]");
                  ch = getch();
                  if ( ch == 'v' ) 
                  { 
                    if ( fexist( idata[ selection ] ) == 1 )
                      nrunwith(  " vim " ,  idata[ selection ] ); 
                  }
                  else if ( ch == 'l' ) 
                  { 
                    if ( fexist( idata[ selection ] ) == 1 )
                      nrunwith(  " less  " ,  idata[ selection ] ); 
                  }
                  else if ( ch == 's' ) 
                  { 
                      nruncmd( " screen " ); 
                      loadlist();
                  }
                  else if ( ch == 'b' ) 
                  { 
                      nruncmd( " bash " ); 
                      loadlist();
                  }
                  else if ( ch == 'c' ) 
                  { 
                      nruncmd( " bash " ); 
                      loadlist();
                  }
                  else if ( ch == 'n' ) 
                  { 
                      nrunwith( " elinks  " , "www.google.com" ); 
                      loadlist();
                  }
                  break;

               case 'r':
                  if ( fexist( idata[ selection ] ) == 1 )
                     nrunwith( " ncview " , idata[ selection ] ); 
                     break;

               case 'o':
                  if ( fexist( idata[ selection ] ) == 1 )
                     nrunelf( idata[ selection ] ); 
                     break;
        }
       }

      curs_set( 1 );
      endwin();			/* End curses mode		  */
      return 0;
}


